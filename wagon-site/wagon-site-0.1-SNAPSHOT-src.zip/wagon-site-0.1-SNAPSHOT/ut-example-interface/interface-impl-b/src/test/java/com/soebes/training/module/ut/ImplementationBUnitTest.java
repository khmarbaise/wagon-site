package com.soebes.training.module.ut;

import org.junit.BeforeClass;


public class ImplementationBUnitTest extends ImplementationUnitTest {

    @BeforeClass
    public static void beforeClass() {
        function = new ImplementationB();
    }

}
