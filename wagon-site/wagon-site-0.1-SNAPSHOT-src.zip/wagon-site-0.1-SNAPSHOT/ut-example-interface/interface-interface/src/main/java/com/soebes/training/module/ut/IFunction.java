package com.soebes.training.module.ut;


/**
 * The definition of the interface for all implementations.
 *
 * @author Karl Heinz Marbaise
 *
 */
public interface IFunction {
    boolean function(String parameter1);
}